package daoImpl;

import dao.GenericDAO;
import Model.BaseEntity;
import java.util.List;

public abstract class GenericDAOImpl<T extends BaseEntity> implements GenericDAO<T> {
}
