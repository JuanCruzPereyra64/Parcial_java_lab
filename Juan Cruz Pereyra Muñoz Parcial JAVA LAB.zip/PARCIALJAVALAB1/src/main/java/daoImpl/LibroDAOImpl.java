package daoImpl;

import dao.LibroDAO;
import Model.Autor;
import Model.Libro;
import util.DBConnection;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class LibroDAOImpl implements LibroDAO {

    @Override
    public void crear(Libro libro) {
        String sql = "INSERT INTO libro (titulo, autor_id, fecha_publicacion) VALUES (?, ?, ?)";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            stmt.setString(1, libro.getTitulo());
            stmt.setInt(2, libro.getAutor().getId());
            stmt.setDate(3, Date.valueOf(libro.getFechaPublicacion()));
            stmt.executeUpdate();
            try (ResultSet rs = stmt.getGeneratedKeys()) {
                if (rs.next()) libro.setId(rs.getInt(1));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public Libro buscarPorId(int id) {
        String sql = "SELECT l.id, l.titulo, l.fecha_publicacion, a.id as autor_id, a.nombre as autor_nombre " +
                "FROM libro l JOIN autor a ON l.autor_id = a.id WHERE l.id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, id);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    Autor autor = new Autor(rs.getInt("autor_id"), rs.getString("autor_nombre"));
                    return new Libro(
                            rs.getInt("id"),
                            rs.getString("titulo"),
                            autor,
                            rs.getDate("fecha_publicacion").toLocalDate()
                    );
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    @Override
    public List<Libro> listarTodos() {
        List<Libro> libros = new ArrayList<>();
        String sql = "SELECT l.id, l.titulo, l.fecha_publicacion, a.id as autor_id, a.nombre as autor_nombre " +
                "FROM libro l JOIN autor a ON l.autor_id = a.id";
        try (Connection conn = DBConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                Autor autor = new Autor(rs.getInt("autor_id"), rs.getString("autor_nombre"));
                Libro libro = new Libro(
                        rs.getInt("id"),
                        rs.getString("titulo"),
                        autor,
                        rs.getDate("fecha_publicacion").toLocalDate()
                );
                libros.add(libro);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return libros;
    }

    @Override
    public void actualizar(Libro libro) {
        String sql = "UPDATE libro SET titulo = ?, autor_id = ?, fecha_publicacion = ? WHERE id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, libro.getTitulo());
            stmt.setInt(2, libro.getAutor().getId());
            stmt.setDate(3, Date.valueOf(libro.getFechaPublicacion()));
            stmt.setInt(4, libro.getId());
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void eliminar(int id) {
        String sql = "DELETE FROM libro WHERE id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, id);
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public List<Libro> buscarPorTitulo(String titulo) {
        List<Libro> libros = new ArrayList<>();
        String sql = "SELECT l.id, l.titulo, l.fecha_publicacion, a.id as autor_id, a.nombre as autor_nombre " +
                "FROM libro l JOIN autor a ON l.autor_id = a.id WHERE l.titulo LIKE ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, "%" + titulo + "%");
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    Autor autor = new Autor(rs.getInt("autor_id"), rs.getString("autor_nombre"));
                    Libro libro = new Libro(
                            rs.getInt("id"),
                            rs.getString("titulo"),
                            autor,
                            rs.getDate("fecha_publicacion").toLocalDate()
                    );
                    libros.add(libro);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return libros;
    }

    @Override
    public List<Libro> buscarPorAutorId(int autorId) {
        List<Libro> libros = new ArrayList<>();
        String sql = "SELECT l.id, l.titulo, l.fecha_publicacion, a.id as autor_id, a.nombre as autor_nombre " +
                "FROM libro l JOIN autor a ON l.autor_id = a.id WHERE a.id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, autorId);
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    Autor autor = new Autor(rs.getInt("autor_id"), rs.getString("autor_nombre"));
                    Libro libro = new Libro(
                            rs.getInt("id"),
                            rs.getString("titulo"),
                            autor,
                            rs.getDate("fecha_publicacion").toLocalDate()
                    );
                    libros.add(libro);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return libros;
    }
}
