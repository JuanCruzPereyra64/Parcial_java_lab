package util;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;

public class DatabaseInitializer {
    public static void inicializarBaseDeDatos() {
        try (Connection conn = DBConnection.getConnection(); Statement stmt = conn.createStatement()) {
            String crearTablaAutor = "CREATE TABLE IF NOT EXISTS autor (" +
                    "id INT AUTO_INCREMENT PRIMARY KEY, " +
                    "nombre VARCHAR(255) NOT NULL" +
                    ")";
            String crearTablaLibro = "CREATE TABLE IF NOT EXISTS libro (" +
                    "id INT AUTO_INCREMENT PRIMARY KEY, " +
                    "titulo VARCHAR(255) NOT NULL, " +
                    "autor_id INT NOT NULL, " +
                    "fecha_publicacion DATE, " +
                    "FOREIGN KEY (autor_id) REFERENCES autor(id) ON DELETE CASCADE" +
                    ")";

            stmt.executeUpdate(crearTablaAutor);
            stmt.executeUpdate(crearTablaLibro);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
