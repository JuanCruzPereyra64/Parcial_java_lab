package Main;

import dao.AutorDAO;
import dao.LibroDAO;
import daoImpl.AutorDAOImpl;
import daoImpl.LibroDAOImpl;
import Model.Autor;
import Model.Libro;
import util.DatabaseInitializer;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Scanner;

public class Main {
    private static final Scanner scanner = new Scanner(System.in);
    private static final AutorDAO autorDAO = new AutorDAOImpl();
    private static final LibroDAO libroDAO = new LibroDAOImpl();

    public static void main(String[] args) {
        DatabaseInitializer.inicializarBaseDeDatos();
        menuPrincipal();
    }

    private static void menuPrincipal() {
        while (true) {
            System.out.println("\n--- MENÚ PRINCIPAL ---");
            System.out.println("1. Gestionar Autores");
            System.out.println("2. Gestionar Libros");
            System.out.println("0. Salir");
            System.out.print("Seleccione una opción: ");
            String opcion = scanner.nextLine();
            switch (opcion) {
                case "1":
                    menuAutores();
                    break;
                case "2":
                    menuLibros();
                    break;
                case "0":
                    System.out.println("Saliendo...");
                    return;
                default:
                    System.out.println("Opción inválida");
            }
        }
    }

    private static void menuAutores() {
        while (true) {
            System.out.println("\n--- GESTIÓN DE AUTORES ---");
            System.out.println("1. Listar todos");
            System.out.println("2. Crear");
            System.out.println("3. Buscar por ID");
            System.out.println("4. Actualizar");
            System.out.println("5. Eliminar");
            System.out.println("0. Volver");
            System.out.print("Opción: ");
            String opcion = scanner.nextLine();
            switch (opcion) {
                case "1":
                    List<Autor> autores = autorDAO.listarTodos();
                    autores.forEach(a -> System.out.println(a.getId() + ": " + a.getNombre()));
                    break;
                case "2":
                    System.out.print("Nombre del autor: ");
                    String nombre = scanner.nextLine();
                    if (nombre.isBlank()) {
                        System.out.println("Nombre inválido");
                        break;
                    }
                    autorDAO.crear(new Autor(nombre));
                    System.out.println("Autor creado.");
                    break;
                case "3":
                    System.out.print("ID del autor: ");
                    int idBuscar = Integer.parseInt(scanner.nextLine());
                    Autor autor = autorDAO.buscarPorId(idBuscar);
                    if (autor != null)
                        System.out.println("Autor: " + autor.getNombre());
                    else
                        System.out.println("No encontrado.");
                    break;
                case "4":
                    System.out.print("ID del autor: ");
                    int idActualizar = Integer.parseInt(scanner.nextLine());
                    Autor autorActual = autorDAO.buscarPorId(idActualizar);
                    if (autorActual == null) {
                        System.out.println("No existe.");
                        break;
                    }
                    System.out.print("Nuevo nombre: ");
                    String nuevoNombre = scanner.nextLine();
                    autorActual.setNombre(nuevoNombre);
                    autorDAO.actualizar(autorActual);
                    System.out.println("Autor actualizado.");
                    break;
                case "5":
                    System.out.print("ID del autor: ");
                    int idEliminar = Integer.parseInt(scanner.nextLine());
                    autorDAO.eliminar(idEliminar);
                    System.out.println("Autor eliminado.");
                    break;
                case "0":
                    return;
                default:
                    System.out.println("Opción inválida");
            }
        }
    }

    private static void menuLibros() {
        while (true) {
            System.out.println("\n--- GESTIÓN DE LIBROS ---");
            System.out.println("1. Listar todos");
            System.out.println("2. Crear");
            System.out.println("3. Buscar por ID");
            System.out.println("4. Actualizar");
            System.out.println("5. Eliminar");
            System.out.println("0. Volver");
            System.out.print("Opción: ");
            String opcion = scanner.nextLine();
            switch (opcion) {
                case "1":
                    List<Libro> libros = libroDAO.listarTodos();
                    libros.forEach(l -> System.out.println(l.getId() + ": " + l.getTitulo() + " - " + l.getAutor().getNombre() + " - " + l.getFechaPublicacion()));
                    break;
                case "2":
                    System.out.print("Título: ");
                    String titulo = scanner.nextLine();
                    System.out.print("ID del autor: ");
                    int idAutor = Integer.parseInt(scanner.nextLine());
                    Autor autor = autorDAO.buscarPorId(idAutor);
                    if (autor == null) {
                        System.out.println("Autor no existe.");
                        break;
                    }
                    System.out.print("Fecha de publicación (YYYY-MM-DD): ");
                    LocalDate fecha = LocalDate.parse(scanner.nextLine(), DateTimeFormatter.ISO_DATE);
                    libroDAO.crear(new Libro(titulo, autor, fecha));
                    System.out.println("Libro creado.");
                    break;
                case "3":
                    System.out.print("ID del libro: ");
                    int idLibro = Integer.parseInt(scanner.nextLine());
                    Libro libro = libroDAO.buscarPorId(idLibro);
                    if (libro != null)
                        System.out.println(libro.getTitulo() + " - " + libro.getAutor().getNombre() + " - " + libro.getFechaPublicacion());
                    else
                        System.out.println("No encontrado.");
                    break;
                case "4":
                    System.out.print("ID del libro: ");
                    int idActualizar = Integer.parseInt(scanner.nextLine());
                    Libro libroActual = libroDAO.buscarPorId(idActualizar);
                    if (libroActual == null) {
                        System.out.println("No existe.");
                        break;
                    }
                    System.out.print("Nuevo título: ");
                    String nuevoTitulo = scanner.nextLine();
                    System.out.print("Nuevo ID del autor: ");
                    int nuevoIdAutor = Integer.parseInt(scanner.nextLine());
                    Autor nuevoAutor = autorDAO.buscarPorId(nuevoIdAutor);
                    if (nuevoAutor == null) {
                        System.out.println("Autor no existe.");
                        break;
                    }
                    System.out.print("Nueva fecha (YYYY-MM-DD): ");
                    LocalDate nuevaFecha = LocalDate.parse(scanner.nextLine(), DateTimeFormatter.ISO_DATE);
                    libroActual.setTitulo(nuevoTitulo);
                    libroActual.setAutor(nuevoAutor);
                    libroActual.setFechaPublicacion(nuevaFecha);
                    libroDAO.actualizar(libroActual);
                    System.out.println("Libro actualizado.");
                    break;
                case "5":
                    System.out.print("ID del libro: ");
                    int idEliminar = Integer.parseInt(scanner.nextLine());
                    libroDAO.eliminar(idEliminar);
                    System.out.println("Libro eliminado.");
                    break;
                case "0":
                    return;
                default:
                    System.out.println("Opción inválida");
            }
        }
    }
}
