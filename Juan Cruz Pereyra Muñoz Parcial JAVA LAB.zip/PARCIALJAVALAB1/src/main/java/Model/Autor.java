package Model;

public class Autor extends BaseEntity {
    private String nombre;

    public Autor(String nombre) {
        this.nombre = nombre;
    }

    public Autor(int id, String nombre) {
        super.setId(id);
        this.nombre = nombre;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
}
