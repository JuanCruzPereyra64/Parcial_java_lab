package dao;

import Model.Autor;
import java.util.List;

public interface AutorDAO extends GenericDAO<Autor> {
    List<Autor> buscarPorNombre(String nombre);
}
