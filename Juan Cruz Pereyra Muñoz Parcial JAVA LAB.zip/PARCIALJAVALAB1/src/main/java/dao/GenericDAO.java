package dao;

import Model.BaseEntity;
import java.util.List;

public interface GenericDAO<T extends BaseEntity> {
    void crear(T entity);
    T buscarPorId(int id);
    List<T> listarTodos();
    void actualizar(T entity);
    void eliminar(int id);
}
