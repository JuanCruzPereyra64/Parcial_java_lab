package dao;

import Model.Libro;
import Model.Libro;
import java.util.List;

public interface LibroDAO extends GenericDAO<Libro> {
    void crear(Libro libro);

    List<Libro> buscarPorTitulo(String titulo);
    List<Libro> buscarPorAutorId(int autorId);
}
